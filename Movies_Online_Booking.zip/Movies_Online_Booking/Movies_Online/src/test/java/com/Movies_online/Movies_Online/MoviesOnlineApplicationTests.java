package com.Movies_online.Movies_Online;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
