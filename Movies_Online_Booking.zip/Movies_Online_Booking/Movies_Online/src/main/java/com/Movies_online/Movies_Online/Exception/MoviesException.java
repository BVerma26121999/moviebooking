package com.Movies_online.Movies_Online.Exception;

public class MoviesException extends Exception {

	public MoviesException( String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}

}
