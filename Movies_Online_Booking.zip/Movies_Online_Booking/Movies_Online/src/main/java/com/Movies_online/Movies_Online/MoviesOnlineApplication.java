package com.Movies_online.Movies_Online;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesOnlineApplication.class, args);
	}

}
